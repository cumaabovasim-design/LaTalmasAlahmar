package com.latlamas.alahmar;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import java.util.*;

public class MainActivity extends Activity {
  GameView game;
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(1024,1024);game=new GameView(this);setContentView(game);}
  static class GameView extends View {
    Paint p=new Paint(3); Random r=new Random(); int screen=0, level=1, score=0, best; long end; ArrayList<RectF> tiles=new ArrayList<>(); int good=-1; Handler h=new Handler();
    SharedPreferences sp;
    GameView(Context c){super(c);sp=c.getSharedPreferences("save",0);best=sp.getInt("best",0);p.setTypeface(Typeface.create("sans",Typeface.BOLD));setFocusable(true);}
    void txt(Canvas c,String s,float x,float y,float size,int color,Paint.Align a){p.setTextSize(size);p.setColor(color);p.setTextAlign(a);p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);}
    protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(Color.rgb(7,17,31)); if(screen==0)home(c);else if(screen==1)play(c);else over(c);}
    void home(Canvas c){float w=getWidth(),h=getHeight();txt(c,"لا تلمس",w/2,h*.28f,42,Color.WHITE,Paint.Align.CENTER);txt(c,"الأحمر",w/2,h*.28f+52,42,Color.rgb(243,38,61),Paint.Align.CENTER);txt(c,"سرعة • تركيز • تحدي",w/2,h*.39f,19,0xffaebdca,Paint.Align.CENTER);button(c,w/2,h*.55f, "ابدأ اللعب",false);txt(c,"أفضل نتيجة: "+best,w/2,h*.68f,18,0xffd5e0ea,Paint.Align.CENTER);txt(c,"اضغط الأخضر وتجنب الأحمر",w/2,h*.75f,15,0xff8295a8,Paint.Align.CENTER);}
    void button(Canvas c,float x,float y,String s,boolean sec){p.setColor(sec?0xff15273a:0xffe51d33);p.setStyle(Paint.Style.FILL);c.drawRoundRect(x-135,y-30,x+135,y+30,18,18,p);txt(c,s,x,y+8,20,Color.WHITE,Paint.Align.CENTER);}
    void play(Canvas c){float w=getWidth(),h=getHeight();txt(c,"المرحلة "+level,28,48,18,Color.WHITE,Paint.Align.LEFT);txt(c,"⭐ "+score,w/2,48,18,Color.WHITE,Paint.Align.CENTER);long left=Math.max(0,(end-System.currentTimeMillis()+999)/1000);txt(c,"⏱ "+left,w-28,48,18,Color.WHITE,Paint.Align.RIGHT);p.setColor(0xff081522);c.drawRoundRect(16,70,w-16,h-20,24,24,p);for(int i=0;i<tiles.size();i++){RectF q=tiles.get(i);p.setColor(i==good?0xff24c66b:0xfff3263d);c.drawRoundRect(q,14,14,p);}if(left<=0){lose();return;}postInvalidateDelayed(100);}
    void over(Canvas c){float w=getWidth(),h=getHeight();txt(c,"لقد خسرت!",w/2,h*.30f,40,0xffff3b50,Paint.Align.CENTER);txt(c,"النتيجة: "+score,w/2,h*.40f,22,Color.WHITE,Paint.Align.CENTER);txt(c,"وصلت إلى المرحلة "+level,w/2,h*.46f,18,0xffb7c4d0,Paint.Align.CENTER);button(c,w/2,h*.58f,"إعادة المحاولة",false);button(c,w/2,h*.70f,"القائمة الرئيسية",true);}
    void newRound(){tiles.clear();int n=Math.min(5+level/2,12);good=r.nextInt(n);float w=getWidth(),h=getHeight();for(int i=0;i<n;i++){float x,y;int tries=0;do{x=25+r.nextFloat()*(w-120);y=95+r.nextFloat()*(h-190);tries++;}while(overlap(x,y)&&tries<100);tiles.add(new RectF(x,y,x+70,y+70));}long seconds=Math.max(3,10-level/3);end=System.currentTimeMillis()+seconds*1000;invalidate();}
    boolean overlap(float x,float y){for(RectF q:tiles)if(Math.hypot(q.left-x,q.top-y)<78)return true;return false;}
    void start(){screen=1;level=1;score=0;newRound();}
    void lose(){if(screen!=1)return;screen=2;if(score>best){best=score;sp.edit().putInt("best",best).apply();}invalidate();}
    public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=1)return true;float x=e.getX(),y=e.getY();if(screen==0){if(y>getHeight()*.48&&y<getHeight()*.62)start();}else if(screen==1){for(int i=0;i<tiles.size();i++)if(tiles.get(i).contains(x,y)){if(i==good){score+=10*level;level++;newRound();}else lose();break;}}else{if(y>getHeight()*.52&&y<getHeight()*.65)start();else if(y>getHeight()*.65&&y<getHeight()*.78){screen=0;invalidate();}}return true;}
  }
}
