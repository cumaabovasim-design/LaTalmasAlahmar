# لا تلمس الأحمر - Android

هذا المشروع جاهز للبناء السحابي عبر GitHub Actions بدون AndroidIDE.

بعد رفع المشروع إلى GitHub:
1. افتح تبويب Actions.
2. اختر Build APK.
3. اضغط Run workflow.
4. بعد انتهاء البناء افتح نتيجة التشغيل وانزل إلى Artifacts.
5. نزّل LaTalmasAlahmar-debug-apk ثم فك الضغط لتحصل على app-debug.apk وتثبته على الهاتف.

الحد الأدنى لنظام أندرويد في المشروع هو Android 6.0 (API 23).
